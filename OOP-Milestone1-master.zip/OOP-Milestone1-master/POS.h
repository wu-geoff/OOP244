// compilation safeguards

// defined values
