// compilation safegaurds

#include <iostream>
// ict namespace 
namespace ict {
   // Date defined Error values





   class Date {
   private:
      // member variables


     // private methods
      int value()const;


   public:
      // constructors


      void set();
      // operator ovrloads

      // methods


      int mdays()const;

      // istream  and ostream read and write methods


   };
   // operator<< and >> overload prototypes for cout and cin

}