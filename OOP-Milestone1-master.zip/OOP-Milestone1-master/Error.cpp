#define _CRT_SECURE_NO_WARNINGS 

#include "Error.h"

namespace ict{
  
}