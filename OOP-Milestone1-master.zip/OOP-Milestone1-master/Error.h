// compilation safegaurds

#include <iostream>
namespace ict {
   class Error {
      char* m_message;
   public:
   // constructors

   // destructor

   // deleted constructor and operator=

   // operator= for c-style strings

   // methods

   // cast overloads

   };
   // operator << overload prototype for cout
}


